from app.telegram.utils import custom_filters


def setup() -> None:
    custom_filters.setup()